// Script untuk update data Supabase dari file Excel.
// Jalankan setiap kali DATA.xlsx / DATA_TARGET_FUAD.xlsx sudah diupdate:
//
//   node scripts/sync-data.mjs
//
// Script ini akan MENGHAPUS SEMUA baris lama di tabel `sales` & `targets`,
// lalu memasukkan ulang seluruh data dari kedua file Excel. Ini otomatis
// menangani baris yang berubah maupun baris baru sekaligus.
//
// PENTING: script ini butuh SUPABASE_SECRET_KEY (bukan anon/publishable key),
// karena RLS hanya mengizinkan anon untuk membaca, bukan menulis. Secret key
// TIDAK BOLEH dipakai di kode frontend/browser — script ini hanya jalan di
// komputer Anda (Node.js), jadi aman.

import { createClient } from '@supabase/supabase-js';
import XLSX from 'xlsx';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
// Env variables dimuat lewat flag `node --env-file=.env` saat menjalankan
// script ini (lihat perintah di README) — tidak perlu package tambahan.

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(__dirname, '..');

const SUPABASE_URL = process.env.VITE_SUPABASE_URL;
const SECRET_KEY = process.env.SUPABASE_SECRET_KEY;

if (!SUPABASE_URL || !SECRET_KEY) {
  console.error(
    'ERROR: pastikan VITE_SUPABASE_URL dan SUPABASE_SECRET_KEY ada di file .env\n' +
      '(SUPABASE_SECRET_KEY diambil dari Supabase -> Settings -> API Keys -> Secret keys)'
  );
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SECRET_KEY);

const SALES_XLSX = path.join(ROOT, 'public/data/DATA.xlsx');
const TARGET_XLSX = path.join(ROOT, 'public/data/DATA_TARGET_FUAD.xlsx');
const BATCH_SIZE = 500;

function toNumber(v) {
  if (typeof v === 'number') return v;
  if (typeof v === 'string') {
    const cleaned = v.replace(/[^\d,.-]/g, '').replace(/\./g, '').replace(',', '.');
    const n = parseFloat(cleaned);
    return isNaN(n) ? 0 : n;
  }
  return 0;
}

function normalizeKey(k) {
  return k.replace(/^["'\s]+|["'\s]+$/g, '').trim().toUpperCase();
}

function normalizeRow(row) {
  const out = {};
  for (const [k, v] of Object.entries(row)) out[normalizeKey(k)] = v;
  return out;
}

function readSheet(filePath) {
  if (!fs.existsSync(filePath)) {
    console.error(`ERROR: file tidak ditemukan: ${filePath}`);
    process.exit(1);
  }
  const wb = XLSX.readFile(filePath, { cellDates: true });
  const sheet = wb.Sheets[wb.SheetNames[0]];
  return XLSX.utils.sheet_to_json(sheet, { defval: '' });
}

async function deleteAll(table) {
  console.log(`Menghapus data lama di tabel "${table}"...`);
  const { error } = await supabase.from(table).delete().gte('id', 0);
  if (error) throw new Error(`Gagal menghapus data lama di "${table}": ${error.message}`);
}

async function insertBatched(table, rows) {
  console.log(`Memasukkan ${rows.length} baris ke tabel "${table}"...`);
  for (let i = 0; i < rows.length; i += BATCH_SIZE) {
    const batch = rows.slice(i, i + BATCH_SIZE);
    const { error } = await supabase.from(table).insert(batch);
    if (error) throw new Error(`Gagal insert batch ke-${i / BATCH_SIZE + 1} di "${table}": ${error.message}`);
    process.stdout.write(`\r  ${Math.min(i + BATCH_SIZE, rows.length)}/${rows.length}`);
  }
  console.log('\n  selesai.');
}

async function syncSales() {
  const raw = readSheet(SALES_XLSX);
  const rows = raw
    .map((r) => {
      const row = normalizeRow(r);
      return {
        nominal: toNumber(row['NOMINAL']),
        supp: String(row['SUPP'] ?? '').trim(),
        depo: String(row['DEPO'] ?? '').trim().toUpperCase(),
        bulan: String(row['BULAN'] ?? '').trim(),
        tahun: row['TAHUN'] ? Number(row['TAHUN']) : 2026,
        kd_grup: String(row['KD GRUP'] ?? '').trim(),
        sales: String(row['SALES'] ?? '').trim(),
        kota: String(row['KOTA'] ?? '').trim().toUpperCase(),
        tele: String(row['TELE'] ?? '').trim(),
      };
    })
    .filter((r) => r.depo && r.sales);

  await deleteAll('sales');
  await insertBatched('sales', rows);
}

async function syncTargets() {
  const raw = readSheet(TARGET_XLSX);
  const monthCols = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
  const rows = raw
    .map((r) => {
      const row = normalizeRow(r);
      return {
        nama_salesman: String(row['NAMA SALESMAN'] ?? '').trim(),
        depo: String(row['DEPO'] ?? '').trim().toUpperCase(),
        supplier: String(row['SUPPLIER'] ?? '').trim().toUpperCase(),
        tahun: row['TAHUN'] ? Number(row['TAHUN']) : new Date().getFullYear(),
        monthly: monthCols.map((c) => toNumber(row[c])),
      };
    })
    .filter((r) => r.nama_salesman);

  await deleteAll('targets');
  await insertBatched('targets', rows);
}

async function main() {
  console.log('=== Sinkronisasi data Excel -> Supabase ===\n');
  await syncSales();
  await syncTargets();
  console.log('\nSelesai! Buka dashboard Anda dan refresh untuk lihat data terbaru.');
}

main().catch((err) => {
  console.error('\nGAGAL:', err.message);
  process.exit(1);
});
